package net.javaguides.ToDo.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import net.javaguides.ToDo.entity.Task;
import net.javaguides.ToDo.repository.TaskRepository;
import net.javaguides.ToDo.service.TaskService;

@Service
public class TaskServiceImpl implements TaskService{

	private TaskRepository taskRepository;
	
	public TaskServiceImpl(TaskRepository taskRepository) {
		super();
		this.taskRepository = taskRepository;
	}

	@Override
	public List<Task> getAllTasks() {
		return taskRepository.findAll();
	}
	
	@Override
	public List<Task> findByDueDate(String dueDate) {
		return taskRepository.findByDueDate(dueDate);
	} 
	//@Override
	//public List<Task> findByTitle(String title) {
	//	return taskRepository.findByTitle(title);
	//} 

	@Override
	public Task saveTask(Task task) {
		return taskRepository.save(task);
	}

	@Override
	public Task getTaskById(Long id) {
		return taskRepository.findById(id).get();
	}

	@Override
	public Task updateTask(Task task) {
		return taskRepository.save(task);
	}
	/*@Override
	public Task updateById(Task task, Long id) {
		
		return taskRepository.updateById(task);
	}*/
	@Override
	public void deleteTaskById(Long id) {
		taskRepository.deleteById(id);	
	}

}
