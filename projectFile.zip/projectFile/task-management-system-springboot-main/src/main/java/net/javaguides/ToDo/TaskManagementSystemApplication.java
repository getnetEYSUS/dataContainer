package net.javaguides.ToDo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import net.javaguides.ToDo.entity.Task;
import net.javaguides.ToDo.repository.TaskRepository;

@SpringBootApplication
public class TaskManagementSystemApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(TaskManagementSystemApplication.class, args);
	}

	@Autowired
	private TaskRepository taskRepository;
	
	@Override
	public void run(String... args) throws Exception {
		
	}

}
